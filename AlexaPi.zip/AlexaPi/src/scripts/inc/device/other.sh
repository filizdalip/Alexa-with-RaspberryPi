#!/bin/bash

# shellcheck disable=SC2034
DESCRIPTION="other SBCs, desktops, or anything else"

function install_device {
    :
}

function install_device_config {
    :
}